# Apollo Cradle OPD Redesign — n8n Automation Workflows

Automates the prenatal OPD patient journey at Apollo Cradle from a 4-hour,
2-visit ordeal into a 90-minute, single-visit coordinated flow.

## The Problem

Every prenatal visit at a maternity hospital requires consultation + diagnostics + follow-up.
Today these are scheduled as independent events: the consultation is booked, but the ultrasound
and lab work are walk-ins ordered *during* the consultation. This creates:

- 45–90 min ultrasound queues (the #1 bottleneck)
- Follow-up visits because the doctor's session ends before results are ready
- 3–4 hours per visit when actual clinical time is ~45 minutes

## The Solution

**Flip the sequence: diagnostics first, consultation last.**

The system pre-books a bundled visit (lab → scan → consultation) so the doctor sees
the patient with the scan already on screen. No follow-up needed.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Workflow 1: Care Plan Generator                             │
│  Trigger: New patient registration                           │
│  → Generates 12–15 visit milestones from due date            │
│  → Books first bundled visit (lab + scan + consultation)     │
│  → Writes care plan to Google Sheet                          │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Workflow 2: Pre-Visit Intake                                │
│  Trigger: Daily at 6pm                                       │
│  → Finds tomorrow's appointments                             │
│  → Sends WhatsApp intake questions                           │
│  → LLM processes responses into structured pre-visit notes   │
│  → Updates doctor's dashboard (Google Sheet)                 │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│  Workflow 3: Post-Visit Automation                            │
│  Trigger: Doctor marks consultation complete                  │
│  → LLM generates patient-friendly visit summary              │
│  → Sends summary via WhatsApp                                │
│  → Auto-schedules next bundled visit from care plan          │
│  → Delivers lab results when ready                           │
└─────────────────────────────────────────────────────────────┘

Supporting:
┌─────────────────────────────────────────────────────────────┐
│  Workflow 4: Missed Milestone Detector                        │
│  Trigger: Weekly (Monday 9am)                                │
│  → Scans all active patients for approaching milestones      │
│  → Flags patients with no appointment within the window      │
│  → Alerts coordinator to priority-book                       │
└─────────────────────────────────────────────────────────────┘
```

## Workflows

| File | Trigger | What it does |
|------|---------|-------------|
| `workflows/01-care-plan-generator.json` | New row in Patient Registry sheet | Generates 9-month care plan, books first bundled visit |
| `workflows/02-pre-visit-intake.json` | Daily schedule (6pm) | Sends WhatsApp intake, processes responses with LLM |
| `workflows/03-post-visit-automation.json` | Webhook (consultation marked complete) | Sends summary, schedules next visit, delivers lab results |
| `workflows/04-missed-milestone-detector.json` | Weekly schedule (Monday 9am) | Flags patients approaching time-critical milestones |

## Setup

### Prerequisites
- n8n (self-hosted or cloud)
- Google Sheets API credentials (service account)
- WhatsApp Business API (or Twilio for SMS fallback)
- Anthropic API key (for Claude LLM nodes)

### Google Sheets Structure

Create one Google Sheet with these tabs:

**Tab: Patient Registry**
| Column | Description |
|--------|-------------|
| patient_id | Unique ID |
| name | Patient name |
| phone | WhatsApp number |
| email | Email address |
| due_date | Expected due date |
| primary_ob | Assigned OB-GYN |
| package_type | Delivery package tier |
| registration_date | When they registered |
| risk_level | normal / high (updated by doctor) |

**Tab: Care Plan**
| Column | Description |
|--------|-------------|
| patient_id | Links to registry |
| visit_number | 1, 2, 3... |
| gestational_week | Target week for this visit |
| visit_type | routine / nt_scan / anomaly_scan / glucose_test / growth_scan / nst |
| diagnostics_needed | e.g., "ultrasound_anomaly, cbc, blood_sugar, thyroid" |
| status | scheduled / completed / missed / overdue |
| scheduled_date | Actual date booked |
| lab_time | Booked lab slot |
| scan_time | Booked ultrasound slot |
| consultation_time | Booked OB consultation slot |

**Tab: Pre-Visit Notes**
| Column | Description |
|--------|-------------|
| patient_id | Links to registry |
| visit_date | Tomorrow's date |
| new_symptoms | Structured from WhatsApp response |
| medication_compliance | Yes/No |
| patient_concerns | Structured from WhatsApp response |
| urgency_flag | normal / urgent (auto-set if concerning symptoms) |

**Tab: Visit Log**
| Column | Description |
|--------|-------------|
| patient_id | Links to registry |
| visit_date | Actual date |
| visit_summary | Patient-friendly summary (LLM generated) |
| clinical_notes | Doctor's notes (raw) |
| diagnostics_completed | Which tests were done |
| next_visit_scheduled | Date of next bundled visit |

### Installation

1. Import each workflow JSON into n8n (Settings → Import Workflow)
2. Configure credentials:
   - Google Sheets OAuth2 or Service Account
   - WhatsApp Business API (or Twilio)
   - Anthropic API key
3. Update the Google Sheet ID in each workflow's Sheet nodes
4. Activate workflows

## Design Principles

1. **Diagnostics first, consultation last** — The visit sequence is flipped so the doctor
   sees the patient with scan results already on screen.

2. **Ejection principle** — Only 3 of 6 pipeline steps use AI (symptom extraction, scan
   duration prediction, summary generation). The care plan generator, bundled scheduler,
   and guided routing are deterministic.

3. **Bundled scheduling** — Each visit books lab + scan + consultation as one atomic
   reservation, not three independent walk-ins.

4. **9-month demand visibility** — The care plan generator knows exactly which scans
   are needed each week, months in advance.

## AI Disclosure

Claude was used as a thinking partner for:
- Workflow architecture design (which steps need AI vs deterministic logic)
- Care plan template based on standard obstetric protocols
- Prompt design for symptom extraction and summary generation
- This documentation

The observation of the Apollo Cradle workflow, the "diagnostics-first" sequencing insight,
and the ultrasound bottleneck identification are from direct firsthand experience.

## License

MIT
